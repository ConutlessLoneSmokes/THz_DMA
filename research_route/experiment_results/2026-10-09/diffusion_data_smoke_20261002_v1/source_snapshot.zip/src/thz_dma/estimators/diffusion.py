"""Conditional VE score prior and approximate annealed Langevin DMA recovery.

Real/imaginary components each use noise standard deviation sigma. Thus their
complex perturbation has variance 2*sigma**2. Positive-sigma likelihood below is
a Gaussian surrogate, not the exact likelihood conditioned on a diffusion state.
"""
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


def pack_channel(channel):
    """Complex (B,K,S,E) -> real (B,2S,E,K), real strips then imaginary strips."""
    channel = channel.permute(0, 2, 3, 1)
    return torch.cat((channel.real, channel.imag), dim=1)


def unpack_channel(tensor):
    real, imag = tensor.chunk(2, dim=1)
    return torch.complex(real, imag).permute(0, 3, 1, 2)


def center_condition(centers, config):
    search = config["search"]
    low = np.array([search["range_min_m"], np.deg2rad(search["azimuth_min_deg"]),
                    np.deg2rad(search["elevation_min_deg"])])
    high = np.array([search["range_max_m"], np.deg2rad(search["azimuth_max_deg"]),
                     np.deg2rad(search["elevation_max_deg"])])
    points = np.asarray(centers)
    if points.shape != (3, 3) or not np.isfinite(points).all() or np.any(high <= low):
        raise ValueError("expected three finite pre-observation centers and valid bounds")
    return (2 * (points - low) / (high - low) - 1).reshape(-1).astype(np.float32)


class ConditionalBlock(nn.Module):
    def __init__(self, inputs, outputs, embedding):
        super().__init__()
        self.first = nn.Conv2d(inputs, outputs, 3, padding=1)
        self.norm1, self.norm2 = nn.GroupNorm(4, outputs), nn.GroupNorm(4, outputs)
        self.condition = nn.Linear(embedding, outputs)
        self.second = nn.Conv2d(outputs, outputs, 3, padding=1)

    def forward(self, x, embedding):
        x = F.silu(self.norm1(self.first(x)) + self.condition(embedding)[:, :, None, None])
        return F.silu(self.norm2(self.second(x)))


class ConditionalScoreNet(nn.Module):
    """Small two-scale U-Net predicts Gaussian corruption epsilon, not channel gain."""
    def __init__(self, channels=16, width=24):
        super().__init__()
        if channels < 2 or channels % 2 or width < 4 or width % 4:
            raise ValueError("even real/imag channels and width divisible by four required")
        embedding = width * 4
        self.register_buffer("noise_frequencies", torch.logspace(0, 2, 8))
        self.embedding = nn.Sequential(nn.Linear(25, embedding), nn.SiLU(),
                                       nn.Linear(embedding, embedding))
        self.enc1 = ConditionalBlock(channels, width, embedding)
        self.enc2 = ConditionalBlock(width, 2*width, embedding)
        self.middle = ConditionalBlock(2*width, 4*width, embedding)
        self.dec2 = ConditionalBlock(6*width, 2*width, embedding)
        self.dec1 = ConditionalBlock(3*width, width, embedding)
        self.output = nn.Conv2d(width, channels, 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, x, sigma, centers):
        phase = sigma.log()[:, None] * self.noise_frequencies[None]
        embedding = self.embedding(torch.cat((phase.sin(), phase.cos(), centers), dim=1))
        first = self.enc1(x, embedding)
        second = self.enc2(F.avg_pool2d(first, 2), embedding)
        middle = self.middle(F.avg_pool2d(second, 2), embedding)
        up = self.dec2(torch.cat((F.interpolate(middle, size=second.shape[-2:], mode="nearest"), second), dim=1), embedding)
        up = self.dec1(torch.cat((F.interpolate(up, size=first.shape[-2:], mode="nearest"), first), dim=1), embedding)
        return self.output(up)


class TorchDmaOperator:
    """Matrix-free fullband CSI operator, exactly matching relative whitening."""
    def __init__(self, operator, pilot_indices, *, tones=128, device="cpu", dtype=torch.complex64):
        if tones < 1:
            raise ValueError("positive fullband tone count required")
        self.tones = tones
        self.indices = torch.as_tensor(pilot_indices, dtype=torch.long, device=device)
        weights = torch.as_tensor(operator.weights, dtype=dtype, device=device)
        scale = torch.as_tensor(np.sqrt(operator.relative_output_noise_variance),
                                dtype=weights.real.dtype, device=device).permute(2, 0, 1)
        self.matrix = weights.conj().permute(1, 2, 0, 3) / scale[..., None]  # K,S,J,E
        self.gram = self.matrix @ self.matrix.conj().transpose(-1, -2)
        if (len(self.indices) != self.matrix.shape[0] or len(self.indices.unique()) != len(self.indices)
                or self.indices.min() < 0 or self.indices.max() >= tones):
            raise ValueError("invalid pilot indices")

    def forward(self, x):
        h = unpack_channel(x)[:, self.indices]
        return torch.einsum("ksje,bkse->bksj", self.matrix, h).permute(0, 2, 3, 1)

    def adjoint(self, y):
        selected = torch.einsum("ksje,bksj->bkse", self.matrix.conj(), y.permute(0, 3, 1, 2))
        h = selected.new_zeros((y.shape[0], self.tones, self.matrix.shape[1], self.matrix.shape[3]))
        h[:, self.indices] = selected
        return pack_channel(h)

    def noise_factor(self, variance, sigma):
        if not math.isfinite(variance) or variance <= 0 or not math.isfinite(sigma) or sigma < 0:
            raise ValueError("positive complex noise variance and nonnegative sigma required")
        covariance = 2 * sigma**2 * self.gram + variance * torch.eye(
            self.gram.shape[-1], device=self.gram.device, dtype=self.gram.dtype)
        return torch.linalg.cholesky(covariance)

    def likelihood_score(self, x, y, factor):
        residual = (y - self.forward(x)).permute(0, 3, 1, 2)
        dual = torch.cholesky_solve(residual[..., None], factor)[..., 0].permute(0, 2, 3, 1)
        return 2 * self.adjoint(dual)  # real gradient of a complex Gaussian log likelihood


@torch.no_grad()
def posterior_samples(model, operator, observation, centers, variance, settings, *, seed):
    """Finite-step approximate annealed Langevin chains; no truth or NMSE input.

    Gaussian surrogate at sigma: C_y = variance*I + 2*sigma**2*A*A^H.
    Its score is added to the learned smoothed prior score. This is an adaptation
    of annealed score-based channel recovery, not an exact calibrated posterior.
    """
    sigma_min, sigma_max = settings["sigma_min"], settings["sigma_max"]
    levels, steps, samples = settings["levels"], settings["steps_per_level"], settings["samples"]
    step_scale = settings["step_scale"]
    if not (math.isfinite(sigma_max) and 0 < sigma_min < sigma_max
            and all(isinstance(n, int) for n in (levels, steps, samples))
            and levels >= 2 and steps >= 1 and samples >= 1
            and 0 < step_scale <= 0.25):
        raise ValueError("invalid sampler schedule")
    model.eval()
    device = observation.device
    rng = torch.Generator(device=device).manual_seed(seed)
    shape = (samples, 2*operator.matrix.shape[1], operator.matrix.shape[3], operator.tones)
    x = torch.randn(shape, device=device, generator=rng) * sigma_max
    condition = centers.expand(samples, -1)
    history = []
    for sigma_tensor in torch.logspace(math.log10(sigma_max), math.log10(sigma_min), levels, device=device):
        sigma = float(sigma_tensor)
        noise_level = x.new_full((samples,), sigma)
        factor = operator.noise_factor(variance, sigma)
        eta = step_scale * sigma**2
        for _ in range(steps):
            score = -model(x, noise_level, condition) / sigma
            score += operator.likelihood_score(x, observation, factor)
            x = x + eta * score + math.sqrt(2*eta) * torch.randn(shape, device=device, generator=rng)
        if not torch.isfinite(x).all():
            raise ArithmeticError("nonfinite posterior iterate")
        history.append({"sigma": sigma, "residual_mean_squared": float(
            (operator.forward(x)-observation).abs().square().mean())})
    # Tweedie final denoising; averaging all chains defines the reported estimate.
    x -= sigma_min * model(x, x.new_full((samples,), sigma_min), condition)
    if not torch.isfinite(x).all():
        raise ArithmeticError("nonfinite final posterior estimate")
    return unpack_channel(x), history
