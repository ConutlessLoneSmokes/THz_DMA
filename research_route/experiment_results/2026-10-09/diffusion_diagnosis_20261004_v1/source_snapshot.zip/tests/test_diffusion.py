"""Physical complex-gradient, deterministic sampler and interrupted-training checks."""
import copy
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]
from thz_dma.estimators.diffusion import (ConditionalScoreNet, TorchDmaOperator,
    pack_channel, unpack_channel, posterior_samples)
from thz_dma.estimators.planar_sparse import PlanarDmaTemplateOperator
from thz_dma.observations.multistrip import observe_multistrip_schedule
import run_direction1_diffusion as runner
from _run_support import RunArchive


class DiffusionTest(unittest.TestCase):
    def test_physical_operator_gradient_and_sampler(self):
        torch.set_num_threads(2)
        rng = np.random.default_rng(31)
        weights = rng.normal(size=(2, 3, 2, 8))+1j*rng.normal(size=(2, 3, 2, 8))
        relative = np.sum(abs(weights)**2, axis=-1).transpose(2, 0, 1)+.2
        old = PlanarDmaTemplateOperator(np.arange(3)+1., np.zeros((2, 8, 3)),
                                       weights, np.zeros(3), relative)
        op = TorchDmaOperator(old, [0, 2, 7], tones=8, dtype=torch.complex128)
        h = torch.tensor(rng.normal(size=(1, 8, 2, 8))+1j*rng.normal(size=(1, 8, 2, 8)))
        x = pack_channel(h)
        torch.testing.assert_close(unpack_channel(x), h)
        observation = observe_multistrip_schedule(weights, h.numpy()[0, [0, 2, 7]],
            pilot_energy_per_re=1, element_noise_variance=.1, rf_noise_variance=.02, rng=rng)
        expected = old.whiten(observation.clean).reshape(old.observation_shape)
        np.testing.assert_allclose(op.forward(x).numpy()[0], expected, atol=1e-12)
        y = torch.tensor(observation.observed)[None]
        self.assertAlmostEqual(float((op.forward(x).conj()*y).sum().real),
                               float((x*op.adjoint(y)).sum()), places=10)
        for sigma in (0, .4):
            z = x.clone().requires_grad_()
            factor = op.noise_factor(.3, sigma)
            residual = (y-op.forward(z)).permute(0, 3, 1, 2)[..., None]
            log_likelihood = -(residual.conj()*torch.cholesky_solve(residual, factor)).sum().real
            gradient, = torch.autograd.grad(log_likelihood, z)
            torch.testing.assert_close(gradient, op.likelihood_score(z, y, factor))
        with self.assertRaises(ValueError):
            op.noise_factor(.3, float("nan"))
        model = ConditionalScoreNet(channels=4, width=4)
        condition = torch.zeros(1, 9)
        out = model(x.float(), torch.ones(1), condition)
        out.square().sum().backward()
        self.assertEqual(out.shape, x.shape)
        op = TorchDmaOperator(old, [0, 2, 7], tones=8)
        settings = dict(sigma_min=.1, sigma_max=1., levels=2, steps_per_level=2,
                        samples=2, step_scale=.05)
        a, _ = posterior_samples(model, op, y.cfloat(), condition, .3, settings, seed=3)
        b, _ = posterior_samples(model, op, y.cfloat(), condition, .3, settings, seed=3)
        torch.testing.assert_close(a, b, rtol=0, atol=0)
        self.assertTrue(torch.isfinite(a).all())

    def test_training_resume(self):
        torch.set_num_threads(2)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "dataset.json").write_text("{}")
            dataset = {"index": {"train": ["a", "b"]}, "real_component_scale": 1.}
            config = {"job": {"data_run_id": "fake"}, "diffusion": {
                "device": "cpu", "network": {"width": 4},
                "posterior": {"sigma_min": .1, "sigma_max": 1.},
                "training": {"seed": 4, "learning_rate": .001, "steps": 3,
                    "batch_size": 1, "gradient_clip_norm": 1., "validation_every": 1}}}
            def batch(directory, names, scale, config, device):
                return torch.ones(len(names), 16, 8, 8), torch.zeros(len(names), 9)
            save = runner.atomic_torch
            def interrupt(path, payload):
                save(path, payload)
                raise KeyboardInterrupt()
            archives = [RunArchive(n, root/n) for n in ("full", "resumed")]
            for archive in archives:
                (archive.directory / "checkpoint").mkdir(parents=True)
            with patch.object(runner, "require_dataset", return_value=(root, dataset)), \
                    patch.object(runner, "load_batch", side_effect=batch), \
                    patch.object(runner, "validate_model", return_value=.5):
                runner.train(archives[0], copy.deepcopy(config))
                with patch.object(runner, "atomic_torch", side_effect=interrupt):
                    with self.assertRaises(KeyboardInterrupt):
                        runner.train(archives[1], copy.deepcopy(config))
                runner.train(archives[1], copy.deepcopy(config))
            states = [torch.load(a.directory / "checkpoint/training.pt", weights_only=True) for a in archives]
            self.assertEqual(states[0]["history"], states[1]["history"])
            for key in states[0]["model"]:
                torch.testing.assert_close(states[0]["model"][key], states[1]["model"][key], rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
