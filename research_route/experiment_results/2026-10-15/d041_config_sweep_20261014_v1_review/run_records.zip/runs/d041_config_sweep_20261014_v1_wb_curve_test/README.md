# d041_config_sweep_20261014_v1_wb_curve_test

wide / curve / test

sweep_summary.csv给出最坏数值方差下的最终指标；configuration_curve.png为配置曲线。
selection.json只由validation生成；test只验证冻结的配置与引导，不重新寻找最小J。
最小J限于本状态库、匹配先验和引导候选；数值敏感及边界选参需结合结果报告。
重用此前测试场景，不能称为新的独立测试集。smoke结果不作性能结论。
