"""Diagnostics and communication metrics."""

