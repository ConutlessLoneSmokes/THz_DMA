"""Audit D-041 pairing, frozen tuning, SNR and final trajectory endpoints."""
import argparse
import csv
import math
from pathlib import Path

import numpy as np
import pandas as pd

from _run_support import PROJECT_ROOT, hash_file, write_json
from run_zhou2025_repro import load_data, read_json, run_directory
from thz_dma.metrics.statistics import bootstrap_interval


def audit(prefix):
    output = PROJECT_ROOT/"results"/prefix
    if output.exists():
        raise FileExistsError("completed audit outputs are immutable; choose a new prefix")
    data = {band: load_data(f"{prefix}_{tag}_data") for band, tag in (("narrow", "nb"), ("wide", "wb"))}
    left, right = data["narrow"], data["wide"]
    if left.counts != right.counts or left.metadata["split_seeds"] != right.metadata["split_seeds"]:
        raise ValueError("unpaired split counts/seeds")
    parameter_names = [name for name in left.metadata["file_sha256"] if name.startswith("parameters/")]
    if not parameter_names or any(left.metadata["file_sha256"][name] != right.metadata["file_sha256"].get(name)
            for name in parameter_names):
        raise ValueError("path geometry and complex gains are not byte-paired")
    with np.load(left.directory/"array.npz", allow_pickle=False) as a, np.load(right.directory/"array.npz", allow_pickle=False) as b:
        for field in ("element_positions_m", "feed_distances_m"):
            np.testing.assert_array_equal(a[field], b[field])
    inventories, frames, checks = [], [], {}
    for band, tag in (("narrow", "nb"), ("wide", "wb")):
        check_dir = run_directory(f"{prefix}_{tag}_check")
        if read_json(check_dir/"status.json")["status"] != "complete":
            raise ValueError("algebra checks must complete")
        checks[band] = read_json(check_dir/"checks.json")
        if not checks[band]["passed"]:
            raise ValueError("failed algebra/whitening check")
        train_dir = run_directory(f"{prefix}_{tag}_clean")
        train_config = read_json(train_dir/"config_resolved.json")["config"]
        expected_updates = train_config["training"]["epochs"]*math.ceil(data[band].counts["train"]/train_config["training"]["batch_size"])
        if (read_json(train_dir/"status.json")["status"] != "complete" or
                read_json(train_dir/"training_summary.json")["trained_steps"] != expected_updates):
            raise ValueError("training budget incomplete")
        for stage, stage_tag in (("full-noiseless", "full"), ("reduced-noiseless", "reduced"), ("noisy", "noisy")):
            val_dir = run_directory(f"{prefix}_{tag}_{stage_tag}_val")
            test_dir = run_directory(f"{prefix}_{tag}_{stage_tag}_test")
            tuning = read_json(val_dir/"tuning.json")
            if read_json(test_dir/"tuning.json") != tuning:
                raise ValueError("test changed frozen validation tuning")
            frozen = read_json(test_dir/"tuning_source.json")
            if frozen != {"run_id": val_dir.name, "sha256": hash_file(val_dir/"tuning.json")}:
                raise ValueError("frozen tuning source differs")
            for directory, split in ((val_dir, "validation"), (test_dir, "test")):
                if read_json(directory/"status.json")["status"] != "complete":
                    raise ValueError(f"incomplete evaluation: {directory.name}")
                config = read_json(directory/"config_resolved.json")["config"]
                summary = read_json(directory/"metrics_summary.json")
                frame = pd.read_csv(directory/"metrics_raw.csv")
                config_count = len(config["diagnostic"]["configuration_counts"])
                expected_operators = 2 if stage == "full-noiseless" else config_count-1 if stage == "reduced-noiseless" else config_count+1
                noise_count = len(config["evaluation_run"]["snr_db"]) if stage == "noisy" else len(config["diagnostic"]["noiseless_likelihood_variances"])
                expected_rows = expected_operators*noise_count*min(config["evaluation_run"][split+"_scenes"], data[band].counts[split])*3
                if summary["rows"] != expected_rows or len(frame) != expected_rows:
                    raise ValueError("evaluation row count differs from predeclared budget")
                if frame.duplicated(["operator", "condition", "scene_id", "estimator"]).any():
                    raise ValueError("duplicate diagnostic records")
                ref = read_json(directory/"observation_reference.json")["reference"]
                if any(r["training_scenes"] != data[band].counts["train"] for r in ref.values()):
                    raise ValueError("SNR reference did not use all training samples")
                if stage == "noisy":
                    measured = frame.likelihood_variance_normalized*10**(frame.target_whitened_snr_db/10)
                    expected = frame.operator.map({name: r["normalized_whitened_power"] for name, r in ref.items()})
                    np.testing.assert_allclose(measured, expected, rtol=1e-12, atol=1e-15)
                    np.testing.assert_allclose(frame.physical_element_noise_complex_variance,
                        frame.likelihood_variance_normalized*data[band].scale**2, rtol=1e-12, atol=1e-30)
                elif not ((frame.observation_noise_variance_normalized == 0).all()
                        and (frame.physical_element_noise_complex_variance == 0).all()):
                    raise ValueError("noiseless observations contain reported physical noise")
                if frame.error_decomposition_relative_gap.max() > 1e-5:
                    raise ValueError("row/null error decomposition failed")
                if not np.isfinite(frame[["nmse_linear", "prediction_energy_ratio", "normalized_correlation"]]).all().all():
                    raise ValueError("nonfinite primary metrics")
                terminal, trace_rows = [], 0
                for chunk in pd.read_csv(directory/"trajectories.csv", chunksize=10000):
                    trace_rows += len(chunk)
                    terminal.append(chunk.loc[(chunk.t == 0) & (chunk.phase == "updated"),
                        ["operator", "condition", "scene_id", "nmse_linear"]])
                final = pd.concat(terminal)
                ddpm = frame.query("estimator == 'clean_ddpm'")
                if trace_rows != len(ddpm)*(config["diffusion"]["steps"]+1) or len(final) != len(ddpm):
                    raise ValueError("trajectory is incomplete")
                merged = ddpm.merge(final, on=["operator", "condition", "scene_id"], validate="one_to_one", suffixes=("", "_trace"))
                np.testing.assert_allclose(merged.nmse_linear, merged.nmse_linear_trace, rtol=1e-12, atol=1e-15)
                dependencies = read_json(directory/"dependencies.json")
                if (dependencies["train_run_id"] != f"{prefix}_{tag}_clean" or dependencies["data_run_id"] != data[band].directory.name
                        or dependencies["dataset_sha256"] != hash_file(data[band].directory/"dataset.json")
                        or dependencies["checkpoint_sha256"] != hash_file(run_directory(dependencies["train_run_id"])/"checkpoint/training.pt")):
                    raise ValueError("data/model dependency changed")
                frame["run_id"] = directory.name
                frames.append(frame)
                inventories.append({"run_id": directory.name, "band": band, "stage": stage, "split": split,
                    "rows": len(frame), "trajectory_rows": trace_rows, "frozen_tuning": split == "test",
                    "variance_sensitivity": summary["numerical_variance_sensitivity"]})
    all_rows = pd.concat(frames, ignore_index=True)
    rng = np.random.default_rng(2026101346)
    means, paired = [], []
    for key, block in all_rows.groupby(["band", "stage", "split", "operator", "condition", "estimator"]):
        values = block.nmse_linear.to_numpy()
        low, high = bootstrap_interval(values, np.mean, rng=rng, resamples=1000)
        means.append(dict(zip(("band", "stage", "split", "operator", "condition", "estimator"), key)) | {
            "scenes": len(block), "nmse_db": float(10*np.log10(max(values.mean(), 1e-30))),
            "nmse_ci95_low_db": 10*math.log10(max(low, 1e-30)), "nmse_ci95_high_db": 10*math.log10(max(high, 1e-30)),
            "mean_prediction_energy_ratio": float(block.prediction_energy_ratio.mean()),
            "mean_correlation": float(block.normalized_correlation.mean()),
            "mean_row_nmse": float(block.row_space_nmse_linear.mean()), "mean_null_nmse": float(block.null_space_nmse_linear.mean())})
    for key, block in all_rows.query("estimator == 'clean_ddpm' and split == 'test'").groupby(["stage", "operator", "condition"]):
        pivot = block.pivot(index="scene_id", columns="band", values="nmse_db")
        if pivot.isna().any().any():
            raise ValueError("unpaired cross-band test scenes")
        difference = (pivot.wide-pivot.narrow).to_numpy()
        paired.append({"stage": key[0], "operator": key[1], "condition": key[2], "scenes": len(pivot),
            "wide_minus_narrow_mean_db": float(difference.mean()),
            "paired_scene_ci95_db": bootstrap_interval(difference, np.mean, rng=rng, resamples=1000),
            "different_matched_priors": True, "single_training_seed": True})
    output.mkdir(parents=True, exist_ok=False)
    pd.DataFrame(means).to_csv(output/"group_summary.csv", index=False)
    pd.DataFrame(inventories).drop(columns="variance_sensitivity").to_csv(output/"run_inventory.csv", index=False)
    result = {"passed": True, "prefix": prefix, "pairing_parameter_batches": len(parameter_names),
        "rows": len(all_rows), "trajectory_rows": sum(r["trajectory_rows"] for r in inventories),
        "smoke_only": bool(all_rows.smoke_only.all()), "diagnostic_only": True,
        "confidence_unit": "paired path scenes; not training-seed uncertainty", "checks": checks,
        "evaluations": inventories, "paired_band_differences": paired,
        "scope": "pairing/freeze/SNR/metric/trajectory audit; no unique causal claim from smoke runs"}
    write_json(output/"audit.json", result)
    (output/"README.md").write_text(
        f"# D-041 核验\n\n`{prefix}`：{len(all_rows)} 条最终指标、{result['trajectory_rows']} 条轨迹。"
        "路径参数、米制阵列、训练集 SNR 标定、测试冻结和轨迹终点核对通过。\n\n"
        + ("本次是 4 次训练更新的小检查，不作为正式学习性能或唯一原因证据。\n" if result["smoke_only"] else
           "这是单训练种子的诊断对照；场景配对区间不表示训练种子不确定度。\n"), encoding="utf-8")
    print(f"audit passed: {len(all_rows)} metric rows, {result['trajectory_rows']} trajectory rows; {output}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", required=True)
    args = parser.parse_args()
    run_directory(args.prefix)  # validate before creating any output
    audit(args.prefix)


if __name__ == "__main__":
    main()
