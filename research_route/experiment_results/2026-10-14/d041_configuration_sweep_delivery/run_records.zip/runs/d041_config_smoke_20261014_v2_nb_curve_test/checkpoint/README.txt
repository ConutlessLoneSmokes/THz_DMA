New acquisition evaluations only; reused data/models are read-only.
